Closurether
=========

##### A network traffic hijack script, including:

  - DNS hijack
  - html code inject
  - HTTP cache poisoning

##### Description:

http://www.cnblogs.com/index-html/p/wifi_hijack_2.html

http://www.cnblogs.com/index-html/p/wifi_hijack_3.html

该 Demo 不再更新。最新版本参考 [wixss 工具](https://github.com/EtherDream/wixss)
