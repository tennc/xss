$(document).ready(function() {
	inputLength("#title","code:first","30");
	inputLength("#recipients","code:eq(1)","15");
	inputLength("#content","code:last","200");
});