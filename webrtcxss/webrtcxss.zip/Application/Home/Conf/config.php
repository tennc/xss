<?php
return array(
	'URL_MODEL' => 2,
	'DB_TYPE' => 'mysql',
	'DB_HOST' => 'localhost',
	'DB_NAME' => 'webrtcxss',
	'DB_USER' => 'root',
	'DB_PWD' => '741521',
	'DB_PORT' => '3306',
	'DB_PREFIX' => 'webrtc_',
);